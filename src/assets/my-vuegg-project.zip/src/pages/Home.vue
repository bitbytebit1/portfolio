<template>
<div id="S1lPUv058I">
  <input class="B1iIwAqI8" value="" placeholder="placeholder" overflow="hidden" text-overflow="ellipsis"/>
</div>
</template>

<script>
export default {
  name: 'home'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#S1lPUv058I {
  --mdc-theme-primary: #673ab7;
  --mdc-theme-secondary: #f44336;
  --mdc-theme-background: #ffffff;
  position: relative;
  margin: auto;
  background-color: #ffffff;
  overflow: hidden;
  width: 100%;
  height: 100%;
}

</style>
